
# Instagram 24hr Story Clone (Client-Side)

Features
- Upload image stories
- Circular story icons
- Story viewer
- Auto close after 5 seconds
- Stories expire after 24 hours
- LocalStorage persistence

Tech
- HTML
- CSS
- JavaScript

Run
Open index.html in a browser.
