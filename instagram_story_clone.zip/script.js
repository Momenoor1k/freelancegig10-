
const upload = document.getElementById("storyUpload")
const storiesContainer = document.getElementById("stories")
const viewer = document.getElementById("viewer")
const viewerImage = document.getElementById("storyImage")
const closeBtn = document.getElementById("closeBtn")

let stories = JSON.parse(localStorage.getItem("stories")) || []
let viewerTimer = null

displayStories()

upload.addEventListener("change", function(){

const file = upload.files[0]

if(!file){
return
}

if(!file.type.startsWith("image/")){
alert("Please upload an image")
return
}

const reader = new FileReader()

reader.onload = function(e){

const story = {
image: e.target.result,
time: Date.now()
}

stories.push(story)

localStorage.setItem("stories", JSON.stringify(stories))

displayStories()

}

reader.readAsDataURL(file)

})

function displayStories(){

storiesContainer.innerHTML=""

stories = stories.filter(story => Date.now() - story.time < 86400000)

localStorage.setItem("stories", JSON.stringify(stories))

stories.forEach((story,index)=>{

const div = document.createElement("div")
div.className="story"

const img = document.createElement("img")
img.src = story.image

div.appendChild(img)

div.addEventListener("click", function(){
openStory(index)
})

storiesContainer.appendChild(div)

})

}

function openStory(index){

viewer.style.display="flex"
viewerImage.src = stories[index].image

if(viewerTimer){
clearTimeout(viewerTimer)
}

viewerTimer = setTimeout(()=>{
closeStory()
},5000)

}

function closeStory(){

viewer.style.display="none"

if(viewerTimer){
clearTimeout(viewerTimer)
}

}

closeBtn.addEventListener("click", closeStory)
