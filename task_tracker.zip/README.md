
# Task Tracker (To-Do List)

Simple JavaScript Task Tracker.

Features
- Add tasks
- Mark tasks as completed
- Delete tasks

Tech
- HTML
- CSS
- JavaScript

Run
Open index.html in a browser.
