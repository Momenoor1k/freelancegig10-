
# Temperature Converter

A simple temperature converter built with HTML, CSS, and JavaScript.

Features:
- Convert between Celsius, Fahrenheit, and Kelvin
- Input validation
- Beginner-friendly structure

Run:
Open index.html in any browser.
