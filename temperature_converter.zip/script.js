
function convertTemp(){

const inputValue = document.getElementById("tempInput").value;
const unit = document.getElementById("unitSelect").value;

if(inputValue === ""){
alert("Please enter a temperature");
return;
}

const temp = parseFloat(inputValue);

if(isNaN(temp)){
alert("Invalid number");
return;
}

let c,f,k;

if(unit === "C"){
c = temp;
f = (c * 9/5) + 32;
k = c + 273.15;
}

if(unit === "F"){
f = temp;
c = (f - 32) * 5/9;
k = c + 273.15;
}

if(unit === "K"){
k = temp;

if(k < 0){
alert("Kelvin cannot be negative");
return;
}

c = k - 273.15;
f = (c * 9/5) + 32;
}

document.getElementById("resultC").innerText = "Celsius: " + c.toFixed(2) + " °C";
document.getElementById("resultF").innerText = "Fahrenheit: " + f.toFixed(2) + " °F";
document.getElementById("resultK").innerText = "Kelvin: " + k.toFixed(2) + " K";

}
