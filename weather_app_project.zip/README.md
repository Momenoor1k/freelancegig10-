
# Simple Weather App

This is a beginner friendly weather app.

Features:
- Search weather by city
- Shows temperature
- Shows wind speed

Tech:
- HTML
- CSS
- JavaScript
- Open-Meteo API

Run:
Open index.html in your browser.
