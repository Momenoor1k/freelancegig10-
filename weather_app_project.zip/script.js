
async function getWeather(){

const city = document.getElementById("locationInput").value;

if(city === ""){
alert("Please enter a city name");
return;
}

try{

const geoURL = `https://geocoding-api.open-meteo.com/v1/search?name=${city}&count=1`;

const geoResponse = await fetch(geoURL);
const geoData = await geoResponse.json();

if(!geoData.results){
document.getElementById("weatherResult").innerHTML = "City not found";
return;
}

const lat = geoData.results[0].latitude;
const lon = geoData.results[0].longitude;

const weatherURL = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`;

const weatherResponse = await fetch(weatherURL);
const weatherData = await weatherResponse.json();

const temp = weatherData.current_weather.temperature;
const wind = weatherData.current_weather.windspeed;

document.getElementById("weatherResult").innerHTML =
`<h3>${city}</h3>
<p>Temperature: ${temp} °C</p>
<p>Wind Speed: ${wind} km/h</p>`;

}catch(error){
document.getElementById("weatherResult").innerHTML = "Error loading weather";
}

}
